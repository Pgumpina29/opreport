<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>CTLC Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/print.css" media="print">

</head>

<body>

<header class="top-header">

<div class="header-left">

<img src="images/railway_logo.png" class="rail-logo">

<div>
<h2>Chief Traction Loco Controller</h2>
<p>Rayagada Division | East Coast Railway</p>
</div>

</div>

<nav>

<ul class="navbar">

<li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>

<li class="dropdown">

<a href="#"><i class="fas fa-table"></i> KK Board</a>

<ul class="dropdown-menu">
<li><a href="uptrains.php">UP Trains</a></li>
<li><a href="dntrains.php">DN Trains</a></li>
<li><a href="kkboard.php">KK Board</a></li>
</ul>

</li>

<li class="dropdown">

<a href="#"><i class="fas fa-train"></i> ML Board</a>

<ul class="dropdown-menu">
<li><a href="mlboard.php">Main Line Board</a></li>
<li><a href="running.php">Running Trains</a></li>
</ul>

</li>

<li class="dropdown">

<a href="#"><i class="fas fa-users"></i> Crew</a>

<ul class="dropdown-menu">
<li><a href="crewbooking.php">Crew Booking</a></li>
<li><a href="crewreports.php">Crew Reports</a></li>
</ul>

</li>

<li class="dropdown">

<a href="#"><i class="fas fa-exchange-alt"></i> CHG</a>

<ul class="dropdown-menu">
<li><a href="handover.php">Charge Handover</a></li>
<li><a href="shiftreport.php">Shift Reports</a></li>
</ul>

</li>

<li class="dropdown">

<a href="#"><i class="fas fa-bolt"></i> DPC</a>

<ul class="dropdown-menu">
<li><a href="distress.php">Distress Locos</a></li>
<li><a href="fuel.php">Fuel Monitoring</a></li>
</ul>

</li>

<li>
<a href="logout.php" class="logout-btn">
<i class="fas fa-sign-out-alt"></i> Logout
</a>
</li>

</ul>

</nav>

</header>

<div class="page-content">